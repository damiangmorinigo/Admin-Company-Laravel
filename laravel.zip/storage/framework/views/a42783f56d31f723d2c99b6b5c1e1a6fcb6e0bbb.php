

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Agregar Registro</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('company.index')); ?>"><i class="fa fa-chevron-left" aria-hidden="true"></i> volver</a></li>
            <li class="breadcrumb-item active" aria-current="page">Agregar</li>
        </ol>
    </nav>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Oops!</strong> Verifique los errores marcados.<br>
    </div>
    <?php endif; ?>

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php else: ?>
    <div><?php echo e($message); ?></div>
    <?php endif; ?>

    <div class="card card-cyan card-outline card-body">
    <div class="row">
        <form action="<?php echo e(route('company.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <div class="container">
                <div class="row">
                    <div class="col-sm-4"> </div>
                    <div class="col-sm-4">
                        <div class="form-group input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Nombre: </span>
                            </div>
                             <input type="text" class="form-control"  placeholder="Nombre" name="nombre" id="nombre"  value="<?php echo e(old('nombre')); ?>">
                            <?php if($errors->has('nombre')): ?>
                            <small id="linkError" class="form-text text-danger"><?php echo e($errors->first('nombre')); ?></small>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="container"><br /></div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-4"> </div>
                    <div class="col-sm-4">
                        <div class="form-group input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Correo: </span>
                            </div>
                             <input type="text" class="form-control"  placeholder="correo@prueba.com" name="correo" id="correo"  value="<?php echo e(old('correo')); ?>">
                            <?php if($errors->has('correo')): ?>
                            <small id="linkError" class="form-text text-danger"><?php echo e($errors->first('correo')); ?></small>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="container"><br /></div>

            <div class="container">
                <div class="row">
                    <div class="col-sm-4"> </div>
                    <div class="col-sm-4">
                        <div class="form-group input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Logo: </span>
                            </div>
                             <input type="file"   name="logo" class="form-control"  >
                        </div>
                        <?php if($errors->has('logo')): ?>
                                <small id="linkError" class="form-text text-danger"><?php echo e($errors->first('logo')); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="container"><br /></div>
            
            <div class="container">
                <div class="row">
                    <div class="col-sm-4"> </div>
                    <div class="col-sm-4">
                        <div class="form-group input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Página Web: </span>
                            </div>
                             <input type="text" class="form-control"  placeholder="prueba.com" name="pagina_web" id="pagina_web"  value="<?php echo e(old('status')); ?>">
                            <?php if($errors->has('pagina_web')): ?>
                            <small id="linkError" class="form-text text-danger"><?php echo e($errors->first('pagina_web')); ?></small>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="container"><br /></div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-4"> </div>
                    <div class="col-sm-4 text-center">
                        <button type="submit" class="btn btn-sm btn-outline-info">Agregar</button>
                    </div>
                </div>
            </div>
        </form>
       
    </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\company-admin\resources\views/company/create.blade.php ENDPATH**/ ?>