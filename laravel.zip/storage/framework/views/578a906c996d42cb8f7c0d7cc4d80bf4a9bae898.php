

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
  <h1 class="mt-4">Empleados</h1>
  
  <div class="row mt-3 mb-3">
    <div class="col-sm-4 text-right">
        <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('employee.create')); ?>" title="Agregar registro"> 
            <i class="fas fa-plus-circle"></i>
            Agregar
        </a>
    </div>
  </div>

  <?php if($message = Session::get('success')): ?>

        <script> 

            Swal.fire({
                      position: "center",
                      icon: "success",
                      title: "Acción realizada correctamente",
                      showConfirmButton: false,
                      timer: 2000,
                    });
        </script>

  <?php endif; ?>
  <div class="row">
    <table class="table">
      <thead>
        <tr class="btn-primary">
          <th scope="col">#</th>
          <th scope="col">Nombre</th>
          <th scope="col">Apellido</th>
          <th scope="col">Compañia</th>
          <th scope="col" class="text-center ml-2">Acciones</th>

        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row">
              <span class="text-center ml-2"><?php echo e($loop->index + 1); ?></span>
            </th>
           
            <td>

              <span ><?php echo e($employee->nombre); ?></span> 

            </td>
            
            <td class="ml-2 px-6 py-2">
              
              <span ><?php echo e($employee->apellido); ?></span>

            </td>

            <td class="ml-2 px-6 py-2">
              
              <span ><?php echo e($employee->company); ?></span>

            </td>


            
            <td>
              <span class="text-center ml-2">
                <form id="form_employee_<?php echo e($employee->id); ?>" action="<?php echo e(route('employee.destroy', $employee->id)); ?>" method="POST">
    
                  <a class="btn btn-sm btn-outline-info" href="<?php echo e(route('employee.edit', $employee->id)); ?>"><i class="fas fa-edit"></i> Editar</a>
   
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
      
                  <button type="button" onclick="javascript:alertDelete('form_employee_<?php echo e($employee->id); ?>')" class="btn btn-sm btn-outline-danger"><i class="fas fa-edit"></i> Borrar</button>
                </form>
              </span>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    
  </div>
  

  <div class="row">
    <div class="col-sm-4 text-center"> </div>
    <div class="col-sm-4 text-center">
      <?php if(isset($empleados)): ?>
        <?php echo e($empleados->links('vendor.pagination.bootstrap-4')); ?>

      <?php endif; ?>
    </div>
    <div class="col-sm-4 text-center"> </div>
  </div>

</div>

<?php $__env->stopSection(); ?>

<script>
    function alertDelete(form) {
        Swal.fire({
            title: "¿Estas seguro?",
            text: "Este cambio sera permanente!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Sí, borrar!",
            }).then((result) => {
            if (result.value) {
                //si presiona la tecla ok //ajax
                $("#"+ form ).submit();
            } //if
        }); //.them
    }
    
</script>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\company-admin\resources\views/employee/index.blade.php ENDPATH**/ ?>